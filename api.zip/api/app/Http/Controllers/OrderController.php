<?php

namespace App\Http\Controllers;

use App\Events\Dashboard\PublishNotifications;
use App\Models\Order;
use App\Models\OrderProduct;
use App\Http\Requests\StoreOrderRequest;
use App\Http\Requests\UpdateOrderRequest;
use App\Traits\CustomerTrait;
use App\Traits\DashboardTrait;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class OrderController extends Controller
{

    use DashboardTrait;
    use CustomerTrait;
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $orders  = Order::get();
        return $orders;
    }

    public function getOrdersBycampaignId($cid){
        //TODO: user lazy loading instead of join
        $orders = Order::with('products')->join('customers','customers.id','orders.customer_id')
        ->join('users','users.id','customers.user_id')
        ->select('orders.id','orders.device_time','orders.order_no','orders.status','orders.location','customers.name as customer','customers.phone as customer_phone','users.name as user')
        ->where('orders.campaign_id',$cid)
        ->orderBy('orders.id','desc')
        ->get();
        return $orders;
    }

    public function getUserOrders($id){
        $orders =  Order::join('customers','customers.id','orders.customer_id')
        ->select('orders.id','orders.order_no','orders.location','orders.created_date','customers.name as customer_name')
        ->where('orders.user_id', $id)
        ->orderBy('orders.id','desc')
        ->get();

            
        $orders->map(function ($val) {
            $val->serverId = $val->id;
            $val->carts = $this->getOrderProducts($val->id);
       });

        $response = [
            "orders" => $orders
        ];

        return response($response, 200);
    }

    public function getUserOrdersByDate($id, $date){

        $orders =  Order::join('customers','customers.id','orders.customer_id')
            ->select('orders.id','orders.order_no','orders.location','orders.created_date','customers.name as customer_name')
            ->where('orders.user_id', $id)
            ->where('orders.created_date', $date)
            ->orderBy('orders.id','desc')
            ->get();

        $orders->map(function ($val) {
            $val->serverId = $val->id;
            $val->carts = $this->getOrderProducts($val->id);
        });

         $response = [
            "orders" => $orders,
         ];

         return response($response, 200);
    }

    private function getOrderProducts($orderId){

        $orderProducts = DB::table("order_products")
            ->join('products','products.id','order_products.product_id')
            ->join('units','units.id','order_products.unit_id')
            ->join('skus','skus.id','order_products.sku_id')
            ->select('products.name as name','order_products.total_amount as totalAmount',
                    'order_products.total_quantity as totalQuantity', 'order_products.unit_id',
                    'order_products.sku_id')
            ->where("order_id", $orderId)
            ->get();

        $orderProducts->map(function ($val) {
                $val->sku = $this->getSku($val->sku_id);
                $val->unit = $this->getUnit($val->unit_id);
        });

         return $orderProducts;
    }

    private function getSku($id){
        $sku = DB::table('skus')
           ->where('id', $id)
           ->select('id','name')
           ->first();

        return $sku;
    }

    private function getUnit($id){
        $unit = DB::table('units')
           ->where('id', $id)
           ->select('id','name')
           ->first();

        return $unit;
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoreOrderRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if(!Order::where('order_no', '=', $request->order_no)->exists()){
            
            $order  = new Order;
            $order->device_time = $request->device_time;
            $order->order_no = $request->order_no;
            $order->status  = $request->status;
            $order->created_date = $request->created_date;
            $order->location = $request->location;
            $order->lng = $request->lng;
            $order->lat = $request->lat;
            $order->user_id  = $request->user_id;
            $order->customer_id = $request->customer_id;
            $order->campaign_id = $request->campaign_id;

            if($order->save()){
            
                foreach (json_decode($request->carts, true) as $cart) {
                    $this->attachToProduct($order->id, $cart);
                }

                //add customer stats
                $this->storeCustomerStats(1,1, collect($request->carts)->sum('total_amount'), $order->lat,$order->lng, $order->user_id, $order->customer_id, $order->campaign_id);

                //push new order to the dashboard as notification
                event(new PublishNotifications($this->getStats( $request->campaign_id)));
                
                return response(["order"=> $order], 201);

            }
        }

    }


    public function getStats( $cid ) {

        $stats = $this->getStatData( $cid );
        $response = [];
        try {
            $response =  [
                'stats' => $stats,
                'notifications' => [
                    'total_new_sales' =>$stats->num_sales,
                    'total_new_customers' => $stats->num_customers,
                    'total_new_revenue' => $stats->revenue,
                    'total_new_customer_visited' => $stats->num_visits
                ]
            ];

        } catch ( \Throwable $th ) {
            //throw $th;
        }
        return response( $response, 200 );

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Order  $order
     * @return \Illuminate\Http\Response
     */
    public function show(Order $order)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Order  $order
     * @return \Illuminate\Http\Response
     */
    public function edit(Order $order)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdateOrderRequest  $request
     * @param  \App\Models\Order  $order
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateOrderRequest $request, Order $order)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Order  $order
     * @return \Illuminate\Http\Response
     */
    public function destroy(Order $order)
    {
        //
    }

    
   public function attachToProduct($oid, $cart){

    //dd($product);
    $order = Order::findOrFail($oid);
  
    //check if cart is a duplicate before adding it
    $cartExist = DB::table("order_products")
        ->where('product_id', $cart["product"]["id"])
        ->where('order_id',  $oid)
        ->where('unit_id', $cart['unit']['id'])
        ->where('sku_id', $cart['sku']['id'])
        ->exists();

    $orderProduct =  new OrderProduct;
    $orderProduct->total_quantity = $cart['totalQuantity'];
    $orderProduct->total_amount  =  $cart['totalAmount'];
    $orderProduct->product_id =  $cart["product"]["id"];
    $orderProduct->order_id = $oid;
    $orderProduct->sku_id = $cart['sku']['id'];
    $orderProduct->unit_id =$cart['unit']['id'];
     
    $orderProduct->save();
     
    // if(!$cartExist){
    $order->products()->syncWithoutDetaching([
        $cart["product"]["id"] => [
            'total_quantity' => $cart['totalQuantity'], 
            'total_amount' => $cart['totalAmount'],
            'sku_id' => $cart['sku']['id'],
            'unit_id' => $cart['unit']['id']
            ]
    ]);
    // }
    
    

  
}

}
