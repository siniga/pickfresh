<?php

namespace App\Traits;

use Illuminate\Support\Facades\DB;

trait DashboardTrait
{
    use OrderTrait;

    public function getStatData($cid)
    {

        // $visits = DB::table( 'customer_users' )
        // ->join( 'customers', 'customers.id', 'customer_users.customer_id' )
        // ->select( 'customers.name' )
        // ->where( 'customers.campaign_id', $cid )
        // ->get();

        $stats = DB::table('customer_stats')
            ->select(
                DB::raw('(SUM(num_visit)) as num_visits'),
                DB::raw('(SUM(num_sale)) as num_sales'),
                DB::raw('SUM(amount) as revenue'),
            )
            ->where('campaign_id', $cid)
            ->groupBy('num_visit')
            ->get();

        if (count($stats) > 0) {
            $stats->map(function ($val) use ($cid) {
                $val->num_customers = $this->getNumOfCustomers($cid);

            });

            return $stats[0];
        }

        return $stats;

    }

    public function getNumOfCustomers($cid)
    {

        $customers = DB::table('customers')
            ->where('campaign_id', $cid)
            ->get();

        return count($customers);
    }

    public function getMonthlyVisits($cid)
    {
        $monthlyVisits = DB::table('customer_stats')->select(
            DB::raw('(SUM(num_visit)) as num_visit'),
            DB::raw('(SUM(num_sale)) as num_sale'),
            DB::raw('MONTHNAME(created_at) as month_name')
        )
            ->whereYear('created_at', date('Y'))
            ->groupBy('month_name')
            ->orderBy('created_at', 'asc')
            ->where('campaign_id', $cid)
            ->get()
            ->toArray();

        $monthlyData = [];

        foreach ($monthlyVisits as $key => $visit) {
            array_push($monthlyData, [$visit->month_name, (int) $visit->num_visit, (int) $visit->num_sale]);
        }

        array_unshift($monthlyData, ['Month', 'Visits', 'Effective sale']);
        return $monthlyData;
    }

    public function getTopProducts($cid)
    {

        $monthlySales = DB::table('order_products')
            ->join('products', 'products.id', 'order_products.product_id')
            ->join('orders', 'orders.id', 'order_products.order_id')
            ->orderBy('order_products.total_quantity', 'desc')
            ->select('products.id','products.name', DB::raw('sum(order_products.total_amount) as total_amount'), DB::raw('COUNT(order_products.total_quantity) as total_quantity'), 'products.img')
            ->distinct()
            ->groupBy('products.id','products.name','products.img')
            ->where('orders.campaign_id', $cid)
            ->get();

        return $monthlySales->sortByDesc(function($data){
             return $data->total_quantity;
         })->values();
    }

    public function getTopProductsByDistricts($cid)
    {

        //get products then group then into districts
        $productsByDist = DB::table("orders")
        ->join('order_products','orders.id','order_products.order_id')
        ->join('products','products.id','order_products.product_id')
        ->join('customers','customers.id','orders.customer_id')
        ->join('districts','districts.id','customers.district_id')
        ->select(
            DB::raw('(SUM(order_products.total_quantity)) as total_quantity'),
            'districts.name as district'
        )->groupBy('district')
        // ->where('customers.campaign_id', $cid)
        ->where('orders.campaign_id', $cid)
        ->get();


        $products = [];

        foreach ($productsByDist as $key => $product) {
            array_push($products, [$product->district, (int) $product->total_quantity]);
        }

        array_unshift($products, ['District', 'total_quantity']);

        return $products;

    }

    public function getTopSalesMen($cid){

        $topSalesmen = DB::table('customer_stats')
            ->join('users', 'users.id', 'customer_stats.user_id')
            //  ->join('orders','users.id','orders.user_id')
            ->selectRaw(
                'users.id,
                users.name,
            SUM(customer_stats.num_visit) as num_visit,
            SUM(customer_stats.num_sale) as num_sale'

            )->groupBy('users.id','users.name')
            ->where('customer_stats.campaign_id', $cid)
            ->limit(10)
            ->get();
      

        $topSalesmen->map(function ($val) {
            $val->product_stats = $this->getOrdersById($val->id, null);
        });

        return $topSalesmen;
    }

    public function getTopCustomers($cid){
        $topCustomers = DB::table('customer_stats')
        ->join('customers','customers.id','customer_stats.customer_id')
        //  ->join('orders','users.id','orders.user_id')
        ->selectRaw(
            'customers.id,
            customers.name,
        SUM(customer_stats.num_visit) as num_visit,
        SUM(customer_stats.num_sale) as num_sale'

        )->groupBy('customers.id','customers.name')
        ->where('customer_stats.campaign_id', $cid)
        ->limit(10)
        ->get();
  

    $topCustomers->map(function ($val) {
        $val->product_stats = $this->getOrdersById(null, $val->id);
    });


        return $topCustomers;
    }

  
  
    public function getLocations($cid, $uid){
        $locations =  DB::table('customer_stats')
        ->join('customers','customers.id','customer_stats.customer_id')
        ->join('customer_types','customer_types.id','customers.customer_type_id')
        ->where('customer_stats.campaign_id', $cid)
        ->orWhere('customer_stats.user_id', $uid)
        ->select('customers.location as name',
        'customer_types.alias as customer_type','customer_stats.user_visit_lat',
        'customer_stats.user_visit_lng','customers.lat','customers.lng')
        ->get();

        $features = [];

        foreach ($locations as $location) {
            $locationFeatures = 
                [
                    "type" => "Feature",
                    "properties" => [
                        "title" => $location->name,
                        // "description" => $location,
                        "customer_type" => $location->customer_type,
                        // "phone" => $location->phone,
                        // "location" => $location->location,
                        // "device_time" => $location->device_time
                    ],
                    "geometry" => [
                        "coordinates" => [(double) $location->lng, (double)$location->lat],
                        "type" => "Point",
                    ]

                ];

            array_push($features, $locationFeatures);
    
        }
    
      
        return ["features"=> $features, "type"=> "FeatureCollection"];
    }
    public function getSalesMenStats($cid){

        $agents = DB::table('customer_stats')
        ->join('users', 'users.id', 'customer_stats.user_id')
        //  ->join('orders','users.id','orders.user_id')
        ->selectRaw(
            'users.id,
            users.name,
        SUM(customer_stats.num_visit) as num_visit,
        SUM(customer_stats.num_sale) as num_sale'

        )->groupBy('users.id','users.name')
        ->where('customer_stats.campaign_id', $cid)
        ->get();
  

    $agents->map(function ($val) {
        $val->product_stats = $this->getOrdersById($val->id, null);
    });

    return $agents;

      
    }

    
}