<?php

namespace App\Http\Controllers;

use App\Traits\DashboardTrait;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ReportController extends Controller {
    //

    use DashboardTrait;

    public function getStats( $cid ) {

        $stats = $this->getStatData( $cid );
        $response = [];
        try {
            $response =  [
                'stats' => $stats,
                'notifications' => [
                    'total_new_sales' =>$stats->num_sales,
                    'total_new_customers' => $stats->num_customers,
                    'total_new_revenue' => $stats->revenue,
                    'total_new_customer_visited' => $stats->num_visits
                ]
            ];

        } catch ( \Throwable $th ) {
            //throw $th;
        }
        return response( $response, 200 );

    }

    public function getTrends( $cid ) {
        $response = [
            'monthly_visits' => $this->getMonthlyVisits( $cid ),
            'top_products' => $this->getTopProducts( $cid ),
            'top_products_by_districts' =>$this->getTopProductsByDistricts( $cid ),
            'top_sales_men' => $this->getTopSalesMen( $cid ),
            'top_customers' =>$this->getTopCustomers( $cid )
        ];

        return response( $response, 200 );
    }

    public function getVisitedLocations($cid, $uid){
        $response = [
            'customer_visited_locations'=> $this->getLocations($cid,$uid),
            'sales_men_stats'=>$this->getSalesMenStats($cid)
        ];

        return response($response, 200);
    }

}
